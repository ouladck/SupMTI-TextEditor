# SupMTI-TextEditor

A stupid Text Editor make with PyGTK.
It's a part of my Python Min-project for SupMTI Rabat.